# Powerline Puppet Module for Boxen

[![Build Status](https://travis-ci.org/boxen/puppet-powerline.png)](https://travis-ci.org/boxen/puppet-powerline)

## Usage

```puppet
include powerline
```

## Required Puppet Modules

* boxen
* homebrew
* stdlib
* python

## Developing

Write code.

Run `script/cibuild`.
