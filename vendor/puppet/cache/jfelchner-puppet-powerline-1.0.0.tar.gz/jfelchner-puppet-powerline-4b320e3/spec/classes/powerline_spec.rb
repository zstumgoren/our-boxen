require 'spec_helper'

describe 'powerline' do
  it do
    should include_class('python')

    should contain_package('git+git://github.com/Lokaltog/powerline')
  end
end
